#!/usr/bin/env python

def ff(filein):	     	 
    """ Reading in clean flow.dat file and creating a dictionary
    INPUT: flow.dat file name including path
    OUTPUT: dictionary, 
    for example ff['time'] will contain the time
    
    example calls:
    flux=fdic.ff('../m25z01/LOGS/flow.dat')
    then flux['time'] contains the time where the fluxes were calculated
    """
    import numpy as n
    import read_ascii
    import sys
    import os
    
    f = open(filein)
    lines = f.readlines()
    f.close()

# read the stored variable names and store them in "names"
    nvars = len(lines[0].split()+lines[2].split())
    
    fout={'names':lines[0].split()+lines[2].split()}
    fout[fout['names'][0]] = float(lines[1].split()[0])
    fout[fout['names'][1]] = float(lines[1].split()[1])
    fout[fout['names'][2]] = float(lines[1].split()[2])

# read data columns
    nlines = len(lines)-3
    ncols  = len(lines[2].split())    
    b= read_ascii.read_ascii(filein,range(0,ncols),lines=[4,nlines+3])

    for i in range(ncols):
      #print i, ligne1[2].split()[i],b[i]
      fout[lines[2].split()[i]]= b[i]
    
    print 'file read!'
    
    return fout

# end pf
# testing the dic
# fin = ff('flowtest.dat')
# print fin['names'],fin['flow']
