#!/usr/bin/env python
#######################################################################
###### Script to plot flows and abundances in the nuclear chart  ######
# Date: 9.10.2010
# written by: Christian Winteler and Urs Frischknecht
import numpy as np
import matplotlib.pyplot as plt
#~ from matplotlib.mpl import colors,cm,colorbar
from matplotlib import colors,cm,colorbar
from matplotlib.patches import Rectangle, Arrow, Circle
from matplotlib.collections import PatchCollection
from matplotlib.offsetbox import AnchoredOffsetbox, TextArea
import fdic
import sys

#######################################################################
#### plot options
# Set axis limit: If default [0,0,0,0] the complete range in (N,Z) will 
# be plotted, i.e. all isotopes, else specify the limits in 
# plotaxis = [xmin,xmax,ymin,ymax] 
##plotaxis=[26,35,26,32]
plotaxis=[24,34,23,31]
#plotaxis=[0,0,0,0]

# elemental labels off/on [0/1]
ilabel = 0

# label for isotopic masses off/on [0/1]
imlabel = 0

# turn lines for magic numbers off/on [0/1]
imagic = 0

# flow is plotted over "prange" dex. If flow < maxflow-prange it is not plotted
prange = 4#4.

#######################################################################
# check command line input
narg = len(sys.argv)
if narg<4:
   print '#######################################################################'
   print 'not enough input!'
   print 'script call: $ script "plot handler" "input-file"'
   print 'example: $ ./fluxplot.py  1  ~/data/modelXYZ/flowfiles/flowtest.dat output'
   print '#######################################################################'
   sys.exit()

# plot handler abundance/flux/abundance+flux plot [0/1/2]
iplot = int(sys.argv[1])
# output file name
outname = sys.argv[3]
# read data file
inpfile = sys.argv[2]
ff = fdic.ff(inpfile)
try:
  flow = np.log10(ff['flow']+1.e-99)
  sort = flow.argsort()
  flow = flow[sort]
  nin  = ff['nin'][sort]
  zin  = ff['zin'][sort] 
  yin  = ff['yin'][sort]
  nout = ff['nout'][sort]
  zout = ff['zout'][sort]
  yout = ff['yout'][sort]
  maxflow = max(flow)
  nzmax = int(max(max(zin),max(zout)))+1
  nnmax = int(max(max(nin),max(nout)))+1
except KeyError:
  if iplot==1 or iplot==2: 
    sys.exit('The read file does not contain flow data')
  nin  = ff['nin']
  zin  = ff['zin']
  yin  = ff['yin']
  nnmax = int(max(nin))+1
  nzmax = int(max(zin))+1
  
nzycheck = np.zeros([nnmax,nzmax,3])
for i in range(len(nin)):
  ni = int(nin[i])
  zi = int(zin[i])
  nzycheck[ni,zi,0] = 1
  nzycheck[ni,zi,1] = yin[i]
  if iplot==1 or iplot==2:
    no = int(nout[i])
    zo = int(zout[i])
    nzycheck[no,zo,0] = 1
    nzycheck[no,zo,1] = yout[i]
    if iplot==1 and flow[i]>maxflow-prange:
      nzycheck[ni,zi,2] = 1
      nzycheck[no,zo,2] = 1
  
  
#######################################################################
# elemental names: elname(i) is the name of element with Z=i 
elname=('n','H','He','Li','Be','B','C','N','O','F','Ne','Na','Mg','Al','Si','P','S','Cl','Ar','K','Ca','Sc','Ti','V','Cr','Mn','Fe',
        'Co','Ni','Cu','Zn','Ga','Ge','As','Se','Br','Kr','Rb','Sr','Y','Zr','Nb','Mo','Tc','Ru','Rh','Pd','Ag','Cd','In','Sn','Sb',
        'Te', 'I','Xe','Cs','Ba','La','Ce','Pr','Nd','Pm','Sm','Eu','Gd','Tb','Dy','Ho','Er','Tm','Yb','Lu','Hf','Ta','W','Re','Os',
        'Ir','Pt','Au','Hg','Tl','Pb','Bi','Po','At','Rn','Fr','Ra','Ac','Th','Pa','U','Np','Pu')

#### create plot

## define axis and plot style (colormap, size, fontsize etc.)
if plotaxis==[0,0,0,0]:
  xdim=10
  ydim=6
else:
  dx = plotaxis[1]-plotaxis[0]
  dy = plotaxis[3]-plotaxis[2]
  ydim = 10
  xdim = ydim*dx/dy
  
format = 'png'#'pdf'
params = {'axes.labelsize':  15,
          'text.fontsize':   15,
          'legend.fontsize': 15,
          'xtick.labelsize': 15,
          'ytick.labelsize': 15,
          'text.usetex': True}
plt.rcParams.update(params)
fig=plt.figure(figsize=(xdim,ydim),dpi=100)
axx = 0.06
axy = 0.10
axw = 0.90
axh = 0.8
ax=plt.axes([axx,axy,axw,axh])

# color map choice for abundances
cmapa = cm.jet
# color map choice for arrows
cmapr = cm.jet#autumn
# if a value is below the lower limit its set to white
cmapa.set_under(color='w')
cmapr.set_under(color='w')
# set value range for abundance colors (log10(Y))
norma = colors.Normalize(vmin=-10,vmax=-3)
# declare scalarmappable for abundances
a2c = cm.ScalarMappable(norm=norma,cmap=cmapa)
a=[]
a2c.set_array(np.array(a))
# set x- and y-axis scale aspect ratio to 1
ax.set_aspect('equal')
#print time,temp and density on top
#~ dummy = ff['time'] - 8.9850010
temp = '%8.3e' %ff['temp']
time = '%8.3e' %ff['time']
#~ time  ='%8.3e' %dummy
dens = '%8.3e' %ff['dens']

box1 = TextArea("t : " + time + " s~~/~~T$_{9}$ : " + temp + "~~/~~$\\rho_{b}$ : " \
              + dens + ' g/cm$^{3}$', textprops=dict(color="k"))
anchored_box = AnchoredOffsetbox(loc=3,
                child=box1, pad=0.,
                frameon=False,
                bbox_to_anchor=(0., 1.02),
                bbox_transform=ax.transAxes,
                borderpad=0.,
                )
ax.add_artist(anchored_box)

## only abundance plotted
if iplot==0 or iplot==2:
  patches = []
  color = []

  for i in range(nzmax):
    for j in range(nnmax):
      if nzycheck[j,i,0]==1:
	# abundance 
        yab = nzycheck[j,i,1] 
        col = a2c.to_rgba(np.log10(yab))
        xy = j-0.5,i-0.5
        rect = Rectangle(xy,1,1,ec='k',color=col,picker=True)
        rect.set_zorder(1)
        ax.add_patch(rect)

#  cb=colorbar.ColorbarBase(ax, cmap=cmapa, norm=norma,orientation='vertical')
  # cb=plt.colorbar(a2c)
  
  # colorbar label
  # cb.set_label('log$_{10}$(Y)')
  
  # plot file name
  graphname = '/home/mreichert/Fortran/plot/flow/out/'+'ab_'+outname+'.'+format
  #~ graphname = '/home/julia/network/winnet/plots/flow/MC/ab_'+outname+'.'+format
  
#~ t = open('transform.dat')  
#~ for line in t.readlines():
  #~ tmp = line.split()
  #~ zz = int(tmp[2])
  #~ nn = int(tmp[1])

  #~ xy = nn,zz
  #~ circ = Circle(xy,radius=0.15,color = 'g',fill=False)
  #~ circ.set_zorder(2)
  #~ ax.add_patch(circ)
#  rect = Rectangle(xy,1,1,ec='k',fc='None',fill='False',lw=3.)
#  rect.set_zorder(2)
#  ax.add_patch(rect)  
  
  
# Add black frames for stable isotopes
f = open('stableiso.dat')




#~ #head = f.readline()
stable = []

for line in f.readlines():
  tmp = line.split()
  zz = int(tmp[2])
  nn = int(tmp[1])
#~ #  ax.plot(nn,zz,'ko',ms=4.5)
#~ #  xy = nn-0.5,zz-0.5
  xy = nn,zz
  circ = Circle(xy,radius=0.1,fc='k')
  circ.set_zorder(2)
  ax.add_patch(circ)
#~ #  rect = Rectangle(xy,1,1,ec='k',fc='None',fill='False',lw=3.)
#~ #  rect.set_zorder(2)
#~ #  ax.add_patch(rect)

if iplot==1 or iplot==2:
  apatches = []
  acolor = []
  m = 0.8/prange
  vmax=np.ceil(max(flow))
  vmin=max(flow)-prange
  b=-vmin*m+0.1
  normr = colors.Normalize(vmin=vmin,vmax=vmax)
  ymax=0.
  xmax=0.

  for i in range(len(nin)):
    x = nin[i]
    y = zin[i]
    dx = nout[i]-nin[i]
    dy = zout[i]-zin[i]
    
    if flow[i]>=vmin:
      arrowwidth = flow[i]*m+b
      arrow = Arrow(x,y,dx,dy, width=arrowwidth)
      if xmax<x:
        xmax=x
      if ymax<y:
        ymax=y
      acol = flow[i]
      apatches.append(arrow)
      acolor.append(acol)

      if iplot==1:
        xy = x-0.5,y-0.5
        rect = Rectangle(xy,1,1,ec='k',fc='None',fill='False',lw=1.)
        rect.set_zorder(2)
        ax.add_patch(rect)
        xy = x+dx-0.5,y+dy-0.5
        rect = Rectangle(xy,1,1,ec='k',fc='None',fill='False',lw=1.)
        rect.set_zorder(2)
        ax.add_patch(rect)

  
  a = PatchCollection(apatches, cmap=cmapr, norm=normr)
  a.set_array(np.array(acolor))
  a.set_zorder(3)
  ax.add_collection(a)
  # cb = plt.colorbar(a)

  # colorbar label
  # cb.set_label('log$_{10}$(f)')
  
  # plot file name
#  graphname = '../plots/fl_'+outname+'.'+format
  graphname = outname+'.'+'png'
  #~ graphname = outname+'.'+format
# decide which array to take for label positions
iarr = 0
if iplot==1: iarr=2

# plot element labels
if ilabel==1:
  for z in range(nzmax):
    try:
      nmin = min(np.argwhere(nzycheck[:,z,iarr]))[0]-1
      ax.text(nmin,z,elname[z],horizontalalignment='center',verticalalignment='center',fontsize='medium',clip_on=True)
    except ValueError:
      continue
      
# plot mass numbers
if imlabel==1:
  for z in range(nzmax):
     for n in range(nnmax):
        a = z+n
	if nzycheck[n,z,iarr]==1:
          ax.text(n,z,a,horizontalalignment='center',verticalalignment='center',fontsize='small',clip_on=True)

# plot lines at magic numbers
if imagic==1:
  ixymagic=[2, 8, 20, 28, 50, 82, 126]
  nmagic = len(ixymagic)
  for magic in ixymagic:
    if magic<=nzmax:
      try:
#        xnmin = min(np.argwhere(nzycheck[:,magic,iarr]))[0]
        xnmax = max(np.argwhere(nzycheck[:,magic,iarr]))[0]
        line = ax.plot([-0.5,xnmax+0.5],[magic-0.5,magic-0.5],lw=0.5,color='gray',ls='--')
        line = ax.plot([-0.5,xnmax+0.5],[magic+0.5,magic+0.5],lw=0.5,color='gray',ls='--')
      except ValueError:
        dummy=0
    if magic<=nnmax:
      try:
#        yzmin = min(np.argwhere(nzycheck[magic,:,iarr]))[0]
        yzmax = max(np.argwhere(nzycheck[magic,:,iarr]))[0]
        line = ax.plot([magic-0.5,magic-0.5],[-0.5,yzmax+0.5],lw=0.5,color='gray',ls='--')
        line = ax.plot([magic+0.5,magic+0.5],[-0.5,yzmax+0.5],lw=0.5,color='gray',ls='--')
      except ValueError:
        dummy=0

# set axis limits
if plotaxis==[0,0,0,0]:
  if iplot==2 or iplot==0: 
    xmax=max(nin)
    ymax=max(zin)
  ax.axis([-0.5,xmax+0.5,-0.5,ymax+0.5])
else:
  ax.axis([plotaxis[0]-0.5,plotaxis[1]+0.5,plotaxis[2]-0.5,plotaxis[3]+0.5])

# set x- and y-axis label
ax.set_xlabel('neutron number')
ax.set_ylabel('proton number')

def onpick1(event):
#  print event.artist 
  if isinstance(event.artist, Rectangle):
    patch = event.artist
    pn = int(patch.get_x()+0.5)
    pz = int(patch.get_y()+0.5)
    pab = '%8.3e' %nzycheck[pn,pz,1]
    tmp = (pn+pz)*nzycheck[pn,pz,1]
    pmf = '%8.3e' %tmp
    print elname[pz] + str(pn+pz) + '  , Y = ' + pab + '  X = ' + pmf

fig.canvas.mpl_connect('pick_event', onpick1)

fig.savefig(graphname,dpi=400)
print graphname,'is done'

#~ plt.show()
