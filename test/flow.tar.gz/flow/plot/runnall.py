#!/usr/bin/env python

import sys, math
import os, shutil
import commands
import re
import threading

class FuncThread(threading.Thread):
    def __init__(self, target, *args):
        self._target = target
        self._args = args
        threading.Thread.__init__(self)
 
    def run(self):
        self._target(*self._args)

def execute(c):
    failure, out = commands.getstatusoutput(c)


threads=[]

flowlist = [10,20,30,40,50,60]

# Plot Testrun
for i in flowlist:
    print i
    
    input  = '../testrun/flow/flow_{n:04d}.dat'.format(n=i)
    output = './'+'flow_{n:04d}_test'.format(n=i)
    
    print 'python2 fluxplot.py 2 ' + input + ' ' + output
    cmd = 'python2 fluxplot.py 2 ' + input + ' ' + output
    
    
    threads.append( FuncThread(execute, cmd) )
    threads[len(threads)-1].start()
    
    if len(threads)==4:
        for t in threads:
            t.join()
        threads=[]
        
        
# Plot Reference
for i in flowlist:
    print i
    
    input  = '../testrun/flow/flow_{n:04d}.dat'.format(n=i)
    output = './'+'flow_{n:04d}_ref'.format(n=i)
    
    print 'python2 fluxplot.py 2 ' + input + ' ' + output
    cmd = 'python2 fluxplot.py 2 ' + input + ' ' + output
    
    
    threads.append( FuncThread(execute, cmd) )
    threads[len(threads)-1].start()
    
    if len(threads)==4:
        for t in threads:
            t.join()
        threads=[]






for t in threads:
    t.join()
